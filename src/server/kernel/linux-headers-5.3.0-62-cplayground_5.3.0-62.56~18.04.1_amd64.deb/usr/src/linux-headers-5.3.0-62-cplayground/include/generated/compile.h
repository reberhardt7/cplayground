/* This file is auto generated, version 56~18.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#56~18.04.1 SMP Thu Jul 9 18:50:58 UTC 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "cplayground-kernel-scratch"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
