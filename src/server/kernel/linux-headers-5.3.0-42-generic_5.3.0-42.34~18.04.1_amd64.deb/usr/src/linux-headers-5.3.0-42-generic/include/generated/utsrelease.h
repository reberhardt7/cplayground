#define UTS_RELEASE "5.3.0-42-generic"
#define UTS_UBUNTU_RELEASE_ABI 42
