/* This file is auto generated, version 34~18.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#34~18.04.1 SMP Fri Mar 27 12:55:56 PDT 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
